#!/bin/bash
set -a
. ./env.txt
set +a
./cli
